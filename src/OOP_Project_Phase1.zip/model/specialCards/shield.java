package model.specialCards;

import model.components.Game;

public class shield extends specialCards {
public  shield(){
    this.setDuration(1);
    this.setName("shield");
    this.setPrice(50);
}

    @Override
    public void run(Object param) {


    }

}
